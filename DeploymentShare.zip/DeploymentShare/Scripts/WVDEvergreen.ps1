﻿######################################################################
#
#  This script downloads the latest binaries for:
#              Microsoft Edge Chromium
#              Notepad++
#              Microsoft OneDrive
#              Microsoft FSLogix
#  and places them in the MDT Deployment Share Folders
#
######################################################################


Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force

Install-Module -Name Evergreen -force
Import-Module -Name Evergreen -force

$MSEdge_MSI = "C:\deploymentshare\applications\Microsoft Edge\MicrosoftEdgeEnterpriseX64.msi"
$Notepadplusplus = "C:\deploymentshare\applications\Notepad++\npp_installer.exe"
$OneDrive = "C:\deploymentshare\applications\Microsoft OneDrive\OneDriveSetup.exe"
$MSFSLogixApps = "C:\deploymentshare\applications\Microsoft FSLogix\"
$MSOffice = "C:\deploymentshare\applications\Microsoft Office365\setup.exe"

$Edgex64URI = Get-MicrosoftEdge | Where-Object {$_.Architecture -eq "x64" -and $_.Channel -eq "Stable"}
$NotepadplusplusURI = Get-NotepadPlusPlus | Where-Object {$_.Architecture -eq "x64" -and $_.URI -match ".exe"}
$OneDriveURI = Get-MicrosoftOneDrive | Where-Object {$_.Ring -eq "Enterprise"}
$FSLogixURI = Get-MicrosoftFSLogixApps
$MSOfficeURI = Get-MicrosoftOffice | Where-Object {$_.Channel -eq "Monthly"}

Invoke-WebRequest -Uri $Edgex64URI.URI -OutFile $MSEdge_MSI
Invoke-WebRequest -Uri $NotepadplusplusURI.URI -OutFile $Notepadplusplus
Invoke-WebRequest -Uri $OneDriveURI.URI -OutFile $OneDrive #-UseBasicParsing
Invoke-WebRequest -Uri $FSLogixURI.URI -OutFile ($MSFSLogixApps + "FsLogix.zip")
Invoke-WebRequest -Uri $MSOfficeURI.URI -OutFile $MSOffice

Expand-Archive -Path ($MSFSLogixApps + "FSLogix.zip") -DestinationPath $MSFSLogixApps -Force