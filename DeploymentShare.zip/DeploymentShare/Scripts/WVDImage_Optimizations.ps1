﻿####WVD IMAGE OPTIMIZATIONS##################################################################################


###Disable Windows Updates####################################################################################

    Write-Host "Disabling Automatic Updates..."
    reg add HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU /v NoAutoUpdate /t REG_DWORD /d 1 /f
    Write-Host "reg add HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU /v NoAutoUpdate /t REG_DWORD /d 1 /f"

#############################################################################################################



###Enter the following commands into the registry editor to fix 5k resolution support#########################

    Write-Host "Fix 5k resolution support"
    reg add "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v MaxMonitors /t REG_DWORD /d 4 /f
    Write-Host "reg add 'HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' /v MaxXResolution /t REG_DWORD /d 5120 /f"
    reg add "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v MaxXResolution /t REG_DWORD /d 5120 /f
    Write-Host " reg add 'HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' /v MaxXResolution /t REG_DWORD /d 5120 /f"
    reg add "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v MaxYResolution /t REG_DWORD /d 2880 /f
    Write-Host "reg add 'HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' /v MaxYResolution /t REG_DWORD /d 2880 /f"
    reg add "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\rdp-sxs" /v MaxMonitors /t REG_DWORD /d 4 /f
    Write-Host "reg add 'HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\rdp-sxs' /v MaxMonitors /t REG_DWORD /d 4 /f"
    reg add "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\rdp-sxs" /v MaxXResolution /t REG_DWORD /d 5120 /f
    Write-Host "reg add 'HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\rdp-sxs' /v MaxXResolution /t REG_DWORD /d 5120 /f"
    reg add "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\rdp-sxs" /v MaxYResolution /t REG_DWORD /d 2880 /f
    Write-Host "reg add 'HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\rdp-sxs' /v MaxYResolution /t REG_DWORD /d 2880 /f"

################################################################################################################



###Enable timezone redirection##################################################################################

    Write-Host "Enabling time zone redirection..."
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" /v fEnableTimeZoneRedirection /t REG_DWORD /d 1 /f
    Write-Host "reg add 'HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' /v fEnableTimeZoneRedirection /t REG_DWORD /d 1 /f"

################################################################################################################



###Disable Storage Sense#########################################################################################

    Write-Host "Disabling Storage Sense..."
    reg add HKCU\Software\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy /v 01 /t REG_DWORD /d 0 /f
    Write-Host "reg add HKCU\Software\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy /v 01 /t REG_DWORD /d 0 /f"

#################################################################################################################