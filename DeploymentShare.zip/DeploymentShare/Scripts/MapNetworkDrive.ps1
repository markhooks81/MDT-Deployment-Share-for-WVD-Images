﻿##############################################################################
#
#  Map Network Drive to \\languagepacks.file.core.windows.net\languagepacks
#
#
#    NB - We need to use managed IDs in future release
#
##############################################################################

$password = ConvertTo-SecureString "eO/uFLcE3H6+RHr02xh78lwGIjccsBR4cARAIEQvMsjVGKFtF2N9XK6P+x/Uhbw2YmVJOAOTTcxPaAuvBY6cUw==" -AsPlainText -Force
$mycred = New-Object System.Management.Automation.PSCredential ("AZURE\LanguagePacks",$password)

New-PSDrive -PSProvider FileSystem -Credential $mycred -Name "x" -Root "\\languagepacks.file.core.windows.net\languagepacks" -Persist

