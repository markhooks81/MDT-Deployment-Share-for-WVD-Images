﻿    Write-Host "Install Sepago"
    $installargs = "-install"
    copy-item -path "." -Destination "C:\Program Files" -Recurse
    cd "C:\program files\sepago"
    Write-Host ('Install CommandLine = ' + "C:\Program Files\Sepago\ITPC-LogAnalyticsAgent.exe " + $installargs)
    Start-Process -FilePath ("C:\Program Files\Sepago\ITPC-LogAnalyticsAgent.exe") -Wait -ArgumentList $installargs