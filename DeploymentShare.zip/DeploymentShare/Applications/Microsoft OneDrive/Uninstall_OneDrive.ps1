﻿####OneDrive Settings Pre-Client Install####################################################

    Write-Host "Remove OneDrive and Configure AllUsersInstall"
	
	Write-Host "Uninstall OneDrive per-user Install"
    $installargs = "/uninstall"
    Write-Host ('Install CommandLine = OneDriveSetup.exe ' + $installargs)
    Start-Process -FilePath ("C:\deploymentshare\applications\Microsoft OneDrive\OneDriveSetup.exe") -Wait -ArgumentList $installargs
	
	REG ADD "HKLM\Software\Microsoft\OneDrive" /v "AllUsersInstall" /t REG_DWORD /d 1 /reg:64

############################################################################################