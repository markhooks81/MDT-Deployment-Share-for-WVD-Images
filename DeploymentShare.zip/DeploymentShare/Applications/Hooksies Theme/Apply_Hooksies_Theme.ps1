﻿###Apply Custom Theme#######################################################################################
   
    $desktoptheme = ".\hooksiestheme.deskthemepack"
    
    Write-Host "Applying Theme to Image"
    Start-Process -FilePath $desktoptheme
    
############################################################################################################