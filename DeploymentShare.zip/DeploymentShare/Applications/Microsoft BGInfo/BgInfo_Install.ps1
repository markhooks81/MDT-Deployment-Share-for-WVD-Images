﻿
$BGInfoFile = '"C:\Program Files\Microsoft BGInfo\bginfo.exe"'
Write-Host "BGInfoFile: " $BGInfoFile
$BGInfoConfigFile = '"C:\Program Files\Microsoft BGInfo\hooksies.bgi"'
Write-Host "BGInfoConfigFile: " $BGInfoConfigFile

Write-Host "Install BGInfo"
copy-item -path "." -Destination "C:\Program Files" -Recurse

Write-Host "Configuring BGInfo"
$STPrin = New-ScheduledTaskPrincipal -GroupId "Users"
$action = New-ScheduledTaskAction -Execute $BGInfoFile -Argument ($BGInfoConfigFile + " /SILENT /NOLICPROMPT /TIMER:0")
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 1)
Register-ScheduledTask -Action $action -Trigger $trigger -Principal $STPrin -TaskName "BGInfo Update" -Description "Set BGInfo to run every 1mins"